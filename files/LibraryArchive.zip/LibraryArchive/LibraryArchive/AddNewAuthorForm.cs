﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryArchive
{
    public partial class AddNewAuthorForm : Form
    {
        //Fields
        public MainMenu mainMenu;
        public AddNewBookForm addNewBookForm;
        public DatabaseConnection db;


        //Constructor
        public AddNewAuthorForm()
        {
            InitializeComponent();
        }


        //Saves new author
        private void saveAuthorButton_Click(object sender, EventArgs e)
        {
            string firstname = firstnameTextbox.Text.Trim();
            string lastname = lastnameTextbox.Text.Trim();
            string nationality = nationalityTextbox.Text.Trim();

            if (!string.IsNullOrWhiteSpace(firstname) &&
                !string.IsNullOrWhiteSpace(lastname) &&
                !string.IsNullOrWhiteSpace(nationality))
            {
                Dictionary<int, Author> authors = db.GetAuthors();
                bool authorExists = db.authors.Values.Any(author =>
                     author.Firstname == firstname &&
                     author.Lastname == lastname &&
                     author.Nationality == nationality);

                if (!authorExists)
                {
                    Author newAuthor = db.AddAuthor(firstname, lastname, nationality);

                    addNewBookForm.authorsCombobox.Items.Add(newAuthor);
                    mainMenu.authorsListbox.Items.Add(newAuthor);
                    mainMenu.nationalityCombobox.Items.Add(newAuthor.Nationality);

                    MessageBox.Show("Author successfully added");
                }
                else
                {
                    MessageBox.Show("This author already exists");
                }

                firstnameTextbox.Clear();
                lastnameTextbox.Clear();
                nationalityTextbox.Clear();

                Hide();
            }
            else
            {
                MessageBox.Show("Some fields are still empty or invalid");
            }
        }


        //Saves changes of author info
        private void saveChangesButton_Click(object sender, EventArgs e)
        {
            Author authorToEdit = (Author)mainMenu.authorsListbox.SelectedItem;
            int authorId = authorToEdit.AuthorId;
            string firstname = firstnameTextbox.Text.Trim();
            string lastname = lastnameTextbox.Text.Trim();
            string nationality = nationalityTextbox.Text.Trim();

            if (!string.IsNullOrWhiteSpace(firstname) &&
                !string.IsNullOrWhiteSpace(lastname) &&
                !string.IsNullOrWhiteSpace(nationality))
            {
                db.EditAuthor(authorId, firstname, lastname, nationality);

                mainMenu.AddNationalitiesToCombobox();
                mainMenu.UpdateAuthorsListBox();

                Hide();
                MessageBox.Show("Changes successfully saved");
            }
            else
            {
                MessageBox.Show("Some fields are empty or invalid");
            }
        }


        //Keeps the form from closing and hides it instead
        private void AddNewAuthorForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }
    }
}
