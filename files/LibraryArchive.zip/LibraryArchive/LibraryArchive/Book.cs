﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryArchive
{
    public class Book
    {
        //Variables
        public int BookId { get; set; }
        public string Title { get; set; }
        public List<Author> Authors { get; set; }
        public string Genre { get; set; }
        public int PageCount { get; set; }
        public short PublicationYear { get; set; }
        public string Language { get; set; }
        public bool IsCheckedOut { get; set; }
        public Member Member { get; set; }


        //Constructor without authors
        public Book(int bookId, string title, string genre, int pageCount, short publicationYear, string language)
        {
            BookId = bookId;
            Title = title;
            Genre = genre;
            PageCount = pageCount;
            PublicationYear = publicationYear;
            Language = language;
            IsCheckedOut = false;
            Member = null;
        }

        
        //Constructor with authors
        public Book(int bookId, string title, List<Author> authors, string genre, int pageCount, short publicationYear, string language, bool isCheckedOut, Member member)
        {
            BookId = bookId;
            Title = title;
            Authors = authors;
            Genre = genre;
            PageCount = pageCount;
            PublicationYear = publicationYear;
            Language = language;
            IsCheckedOut = isCheckedOut;
            Member = member;
        }


        //Displays title and author
        public override string ToString()
        {
            string authorsString = string.Join(", ", Authors.Select(author => $"{author.Firstname} {author.Lastname}"));
            return "\"" + Title + "\"" + " by "+ authorsString;
        }


        //Displays book info
        public string DisplayDetailsString()
        {
            if (IsCheckedOut)
            {
                return "Genre: " + Genre + "\r\n\r\n" +
                       "Pages: " + PageCount + "\r\n\r\n" +
                       "Publication year: " + PublicationYear + "\r\n\r\n" +
                       "Language: " + Language + "\r\n\r\n" +
                       "Available for checkout: No";
            }
            else
            {
                return "Genre: " + Genre + "\r\n\r\n" +
                       "Pages: " + PageCount + "\r\n\r\n" +
                       "Publication year: " + PublicationYear + "\r\n\r\n" +
                       "Language: " + Language + "\r\n\r\n" +
                       "Available for checkout: Yes";
            }
        }
    }
}

