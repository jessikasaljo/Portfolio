using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cmp;
using System.Diagnostics;
using System.Net;
using System.Text;
using static System.Reflection.Metadata.BlobBuilder;

namespace LibraryArchive
{
    public partial class MainMenu : Form
    {
        //Fields
        private bool booksLabelClicked;
        private bool authorsLabelClicked;
        private bool membersLabelClicked;
        public DatabaseConnection db = new DatabaseConnection();
        public AddNewBookForm addNewBookForm = new AddNewBookForm();
        public AddNewAuthorForm addNewAuthorForm = new AddNewAuthorForm();
        public AddNewMemberForm addNewMemberForm = new AddNewMemberForm();



        //Constructor
        public MainMenu()
        {
            InitializeComponent();
            addNewBookForm.mainMenu = this;
            addNewBookForm.addNewAuthorForm = addNewAuthorForm;
            addNewBookForm.db = db;

            addNewAuthorForm.mainMenu = this;
            addNewAuthorForm.addNewBookForm = addNewBookForm;
            addNewAuthorForm.db = db;

            addNewMemberForm.mainMenu = this;
            addNewMemberForm.db = db;

            db.mainMenu = this;
        }


        //Search box
        private void searchIcon_Click(object sender, EventArgs e)
        {
            booksLabelClicked = false;
            authorsLabelClicked = false;
            membersLabelClicked = false;
            booksLabel.BackColor = Color.Sienna;
            authorsLabel.BackColor = Color.Chocolate;
            membersLabel.BackColor = Color.Peru;
            booksPanel.Visible = true;
            authorsPanel.Visible = false;
            membersPanel.Visible = false;

            string searchTerm = searchTextbox.Text;
            if (!string.IsNullOrEmpty(searchTerm))
            {
                List<Book> matchingBooks = db.SearchBooksByTitle(searchTerm);

                booksListbox.Items.Clear();

                foreach (Book book in matchingBooks)
                {
                    booksListbox.Items.Add(book);
                }
            }
        }


        //BOOKSLABEL
        //Shows book panel and changes visuals
        private void booksLabel_Click(object sender, EventArgs e)
        {
            booksLabelClicked = true;
            authorsLabelClicked = false;
            membersLabelClicked = false;
            booksLabel.BackColor = Color.Black;
            authorsLabel.BackColor = Color.Chocolate;
            membersLabel.BackColor = Color.Peru;

            booksPanel.Visible = true;
            authorsPanel.Visible = false;
            membersPanel.Visible = false;

            if (booksListbox.Items.Count == 0)
            {
                UpdateBooksListbox();
            }

            AddGenresToCombobox();
            AddLanguagesToCombobox();
            AddAuthorsToCombobox();
        }

        private void booksLabel_MouseEnter(object sender, EventArgs e)
        {
            booksLabel.BackColor = Color.Black;
        }

        private void booksLabel_MouseLeave(object sender, EventArgs e)
        {
            if (!booksLabelClicked)
            {
                booksLabel.BackColor = Color.Sienna;
            }
        }


        //AUTHORSLABEL
        //Shows authors panel and changes visuals
        private void authorsLabel_Click(object sender, EventArgs e)
        {
            booksLabelClicked = false;
            authorsLabelClicked = true;
            membersLabelClicked = false;
            booksLabel.BackColor = Color.Sienna;
            authorsLabel.BackColor = Color.Black;
            membersLabel.BackColor = Color.Peru;

            booksPanel.Visible = false;
            authorsPanel.Visible = true;
            membersPanel.Visible = false;

            if (authorsListbox.Items.Count == 0)
            {
                UpdateAuthorsListBox();
            }

            AddNationalitiesToCombobox();
        }

        private void authorsLabel_MouseEnter(object sender, EventArgs e)
        {
            authorsLabel.BackColor = Color.Black;
        }

        private void authorsLabel_MouseLeave(object sender, EventArgs e)
        {
            if (!authorsLabelClicked)
            {
                authorsLabel.BackColor = Color.Chocolate;
            }
        }


        //MEMBERSLABEL
        //Shows members panel and changes visuals
        private void membersLabel_Click(object sender, EventArgs e)
        {
            booksLabelClicked = false;
            authorsLabelClicked = false;
            membersLabelClicked = true;
            booksLabel.BackColor = Color.Sienna;
            authorsLabel.BackColor = Color.Chocolate;
            membersLabel.BackColor = Color.Black;

            booksPanel.Visible = false;
            authorsPanel.Visible = false;
            membersPanel.Visible = true;

            if (allMembersListbox.Items.Count == 0)
            {
                UpdateMembersListBox();
            }
        }

        private void membersLabel_MouseEnter(object sender, EventArgs e)
        {
            membersLabel.BackColor = Color.Black;
        }

        private void membersLabel_MouseLeave(object sender, EventArgs e)
        {
            if (!membersLabelClicked)
            {
                membersLabel.BackColor = Color.Peru;
            }
        }


        //BOOKS PANEL
        //Stops user from changing the text in the comboboxes
        private void languageCombobox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void authorCombobox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void genreCombobox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }


        //Shows details when clicking a book
        private void booksListbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (booksListbox.SelectedItem != null)
            {
                Book selectedBook = (Book)booksListbox.SelectedItem;
                detailsLabel.Text = selectedBook.DisplayDetailsString();
            }
        }


        //Opens new form for adding a new book to library
        private void newBookButton_Click(object sender, EventArgs e)
        {
            addNewBookForm.Text = "Add new book";
            addNewBookForm.authorsCombobox.Text = "Authors";
            addNewBookForm.saveBookButton.Visible = true;
            addNewBookForm.saveChangesButton.Visible = false;
            addNewBookForm.Show();
        }


        //Filters by language
        private void languageCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (languageCombobox.SelectedItem != null && languageCombobox.SelectedItem != "All languages")
            {
                genreCombobox.Text = "Filter by genre";
                authorCombobox.Text = "Filter by author";

                booksListbox.Items.Clear();
                foreach (Book book in db.books.Values)
                {
                    if (book.Language == (string)languageCombobox.SelectedItem)
                    {
                        booksListbox.Items.Add(book);
                    }
                }
            }
            else if (languageCombobox.SelectedItem == "All languages")
            {
                UpdateBooksListbox();
            }
        }


        //Filters by genre
        private void genreCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (genreCombobox.SelectedItem != null && genreCombobox.SelectedItem != "All genres")
            {
                languageCombobox.Text = "Filter by language";
                authorCombobox.Text = "Filter by author";

                booksListbox.Items.Clear();
                foreach (Book book in db.books.Values)
                {
                    if (book.Genre == (string)genreCombobox.SelectedItem)
                    {
                        booksListbox.Items.Add(book);
                    }
                }
            }
            else if (genreCombobox.SelectedItem == "All genres")
            {
                UpdateBooksListbox();
            }
        }


        //Filters by author
        private void authorCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (authorCombobox.SelectedItem != null && authorCombobox.SelectedItem != "All authors")
            {
                genreCombobox.Text = "Filter by genre";
                languageCombobox.Text = "Filter by language";

                booksListbox.Items.Clear();
                Author selectedAuthor = (Author)authorCombobox.SelectedItem;

                foreach (Book book in db.books.Values)
                {
                    if (book.Authors.Any(author => author.Equals(selectedAuthor)))
                    {
                        booksListbox.Items.Add(book);
                    }
                }
            }
            else if (authorCombobox.SelectedItem == "All authors")
            {
                UpdateBooksListbox();
            }
        }


        //Shows only checked out books
        private void checkedOutCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (checkedOutCheckbox.Checked)
            {
                availableBooksCheckbox.Checked = false;
                booksListbox.Items.Clear();
                foreach (Book book in db.books.Values)
                {
                    if (book.IsCheckedOut)
                    {
                        booksListbox.Items.Add(book);
                    }
                }
            }
            else if (!checkedOutCheckbox.Checked)
            {
                UpdateBooksListbox();
            }
        }


        //Shows only books available for checkout
        private void availableBooksCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (availableBooksCheckbox.Checked)
            {
                checkedOutCheckbox.Checked = false;
                booksListbox.Items.Clear();
                foreach (Book book in db.books.Values)
                {
                    if (!book.IsCheckedOut)
                    {
                        booksListbox.Items.Add(book);
                    }
                }
            }
            else if (!availableBooksCheckbox.Checked)
            {
                UpdateBooksListbox();
            }
        }


        //Opens new panel to select member for checkout
        private void checkoutButton_Click(object sender, EventArgs e)
        {
            if (booksListbox.SelectedItem == null)
            {
                MessageBox.Show("Select a book to check out");
            }
            else
            {
                Book selectedBook = (Book)booksListbox.SelectedItem;
                if (selectedBook.IsCheckedOut)
                {
                    MessageBox.Show("This book is already checked out");
                }
                else
                {
                    chooseMemberPanel.Visible = true;
                    if (membersListbox.Items.Count == 0)
                    {
                        Dictionary<int, Member> members = db.GetMembers();
                        foreach (var member in members.Values)
                        {
                            membersListbox.Items.Add(member);
                        }
                    }
                }
            }
        }


        //Checks out book for selected member
        private void confirmMemberButton_Click(object sender, EventArgs e)
        {
            if (membersListbox.SelectedItem == null)
            {
                MessageBox.Show("Please select a member to check out book");
            }
            else
            {
                Book selectedBook = (Book)booksListbox.SelectedItem;
                Member selectedMember = (Member)membersListbox.SelectedItem;
                selectedBook.Member = (Member)membersListbox.SelectedItem;
                selectedMember.Books.Add(selectedBook);
                selectedBook.IsCheckedOut = true;

                db.connection.Open();

                string query = "UPDATE books SET member_id = @MemberId, is_checked_out = @IsCheckedOut WHERE book_id = @BookId";

                MySqlCommand command = new MySqlCommand(query, db.connection);
                command.Parameters.AddWithValue("@MemberId", selectedMember.MemberId);
                command.Parameters.AddWithValue("@IsCheckedOut", 1);
                command.Parameters.AddWithValue("@BookId", selectedBook.BookId);

                command.ExecuteNonQuery();

                db.connection.Close();

                selectedBook.IsCheckedOut = true;
                MessageBox.Show("Book checked out successfully");

                detailsLabel.Text = selectedBook.DisplayDetailsString();
                memberBooksListbox.Items.Add(selectedBook);
                chooseMemberPanel.Visible = false;
            }
        }


        //Returns book
        private void returnButton_Click(object sender, EventArgs e)
        {
            ReturnBook(booksListbox);
        }


        //Opens new window to edit book
        private void editBookButton_Click(object sender, EventArgs e)
        {
            if (booksListbox.SelectedItem != null)
            {
                addNewBookForm.Text = "Edit book";
                addNewBookForm.authorsCombobox.Text = "Authors";
                addNewBookForm.saveBookButton.Visible = false;
                addNewBookForm.saveChangesButton.Visible = true;

                Book selectedBook = (Book)booksListbox.SelectedItem;
                addNewBookForm.Show();
                addNewBookForm.titleTextbox.Text = selectedBook.Title;
                addNewBookForm.genreTextbox.Text = selectedBook.Genre;
                addNewBookForm.languageTextbox.Text = selectedBook.Language;
                addNewBookForm.pagesNumeric.Value = selectedBook.PageCount;
                addNewBookForm.publicationYearNumeric.Value = selectedBook.PublicationYear;

                addNewBookForm.authorsListbox.Items.Clear();
                foreach (Author author in selectedBook.Authors)
                {
                    addNewBookForm.authorsListbox.Items.Add(author);
                }
            }
            else
            {
                MessageBox.Show("Select a book to edit");
            }
        }


        //Removes book
        private void removeBookButton_Click(object sender, EventArgs e)
        {
            if (booksListbox.SelectedItem != null)
            {
                Book selectedBook = (Book)booksListbox.SelectedItem;
                selectedBook.Authors = db.GetAuthorsForBook(selectedBook.BookId);
                
                if (selectedBook.IsCheckedOut)
                {
                    MessageBox.Show("You can't remove a book that is currently checked out");
                }
                else
                {
                    db.RemoveBook(selectedBook);
                    db.books.Remove(selectedBook.BookId);
                    UpdateBooksListbox();
                    MessageBox.Show("Book successfully removed");
                    detailsLabel.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Select a book to remove");
            }
        }


        //Back to book view if not wanting to checkout book
        private void backToBooksButton_Click(object sender, EventArgs e)
        {
            chooseMemberPanel.Visible = false;
        }


        //AUTHORS PANEL
        //Filters by selected nationality
        private void nationalityCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            db.authors = db.GetAuthors();
            if (nationalityCombobox.SelectedItem != null && nationalityCombobox.SelectedItem != "All nationalities")
            {
                authorsListbox.Items.Clear();
                foreach (Author author in db.authors.Values)
                {
                    if (author.Nationality == (string)nationalityCombobox.SelectedItem)
                    {
                        authorsListbox.Items.Add(author);
                    }
                }
            }
            else if (nationalityCombobox.SelectedItem == "All nationalities")
            {
                authorsListbox.Items.Clear();
                foreach (Author author in db.authors.Values)
                {
                    authorsListbox.Items.Add(author);
                }
            }
        }


        //Displays info about selected author
        private void authorsListbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (authorsListbox.SelectedItem != null)
            {
                Author selectedAuthor = (Author)authorsListbox.SelectedItem;
                selectedAuthor.Books = db.GetBooksForAuthor(selectedAuthor.AuthorId);

                StringBuilder detailsBuilder = new StringBuilder();
                detailsBuilder.AppendLine("Author's nationality: " + selectedAuthor.Nationality);
                detailsBuilder.AppendLine();
                detailsBuilder.AppendLine("The library owns " + selectedAuthor.Books.Count + " title(s) by this author:\r\n");

                foreach (Book book in selectedAuthor.Books)
                {
                    detailsBuilder.AppendLine(book.Title);
                }

                authorDetailsLabel.Text = detailsBuilder.ToString();
            }
        }


        //Opens form to add new author
        private void addNewAuthorButton_Click(object sender, EventArgs e)
        {
            addNewAuthorForm.Text = "Add new author";
            addNewAuthorForm.saveAuthorButton.Visible = true;
            addNewAuthorForm.saveChangesButton.Visible = false;
            addNewAuthorForm.Show();
        }


        //Removes author
        private void removeAuthorButton_Click(object sender, EventArgs e)
        {
            if (authorsListbox.SelectedItem != null)
            {
                Author selectedAuthor = (Author)authorsListbox.SelectedItem;
                selectedAuthor.Books = db.GetBooksForAuthor(selectedAuthor.AuthorId);
                int bookCount = selectedAuthor.Books.Count;

                if (bookCount > 0)
                {
                    MessageBox.Show("You can't remove an author who has books currently available in the library");
                }
                else
                {
                    db.RemoveAuthor(selectedAuthor);
                    UpdateAuthorsListBox();
                    MessageBox.Show("Author successfully removed");
                    authorDetailsLabel.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Select an author to remove");
            }
        }


        //Opens new window to edit author
        private void editAuthorButton_Click(object sender, EventArgs e)
        {
            if (authorsListbox.SelectedItem != null)
            {
                addNewAuthorForm.Text = "Edit author";
                addNewAuthorForm.saveAuthorButton.Visible = false;
                addNewAuthorForm.saveChangesButton.Visible = true;

                Author selectedAuthor = (Author)authorsListbox.SelectedItem;
                addNewAuthorForm.Show();
                addNewAuthorForm.firstnameTextbox.Text = selectedAuthor.Firstname;
                addNewAuthorForm.lastnameTextbox.Text = selectedAuthor.Lastname;
                addNewAuthorForm.nationalityTextbox.Text = selectedAuthor.Nationality;
            }
            else
            {
                MessageBox.Show("Select an author to edit");
            }
        }


        //MEMBERS PANEL
        //Displays info about selected member
        private void allMembersListbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (allMembersListbox.SelectedItem != null)
            {
                Member selectedMember = (Member)allMembersListbox.SelectedItem;
                selectedMember.Books = db.GetBooksForMember(selectedMember.MemberId);
                memberDetailsLabel.Text = db.GetMemberInfo(selectedMember.MemberId);

                if (selectedMember.Books.Count > 0)
                {
                    returnBookButton.Visible = true;
                    memberBooksListbox.Visible = true;
                    checkedOutBooksLabel.Visible = true;
                    checkedOutBooksLabel.Text = selectedMember.Firstname + " currently has these books checked out:";

                    memberBooksListbox.Items.Clear();
                    if (memberBooksListbox.Items.Count == 0)
                    {
                        foreach (Book book in selectedMember.Books)
                        {
                            memberBooksListbox.Items.Add(book);
                        }
                    }
                }
                else if (selectedMember.Books.Count <= 0)
                {
                    returnBookButton.Visible = false;
                    checkedOutBooksLabel.Visible = false;
                    memberBooksListbox.Visible = false;
                }
            }
        }


        //Return book from members panel
        private void returnBookButton_Click(object sender, EventArgs e)
        {
            ReturnBook(memberBooksListbox);
        }


        //Opens new window to edit member
        private void editMemberButton_Click(object sender, EventArgs e)
        {
            if (allMembersListbox.SelectedItem != null)
            {
                addNewMemberForm.Text = "Edit member";
                addNewMemberForm.saveMemberButton.Visible = false;
                addNewMemberForm.saveChangesButton.Visible = true;

                Member selectedMember = (Member)allMembersListbox.SelectedItem;
                addNewMemberForm.firstnameTextbox.Text = selectedMember.Firstname;
                addNewMemberForm.lastnameTextbox.Text = selectedMember.Lastname;
                addNewMemberForm.emailTextbox.Text = selectedMember.Email;
                addNewMemberForm.phonenumberTextbox.Text = selectedMember.PhoneNumber;
                addNewMemberForm.addressTextbox.Text = selectedMember.Address;

                addNewMemberForm.Show();
            }
            else
            {
                MessageBox.Show("Select a member to edit");
            }
        }


        //Removes member
        private void removeMemberButton_Click(object sender, EventArgs e)
        {
            if (allMembersListbox.SelectedItem != null)
            {
                Member selectedMember = (Member)allMembersListbox.SelectedItem;
                selectedMember.Books = db.GetBooksForMember(selectedMember.MemberId);
                int bookCount = selectedMember.Books.Count;

                if (bookCount > 0)
                {
                    MessageBox.Show("You can't remove a member who has books currently checked out");
                }
                else
                {
                    db.RemoveMember(selectedMember);
                    UpdateMembersListBox();
                    MessageBox.Show("Member successfully removed");
                }
            }
            else
            {
                MessageBox.Show("Select a member to remove");
            }
        }


        //Opens new window to add new member
        private void addNewMemberButton_Click(object sender, EventArgs e)
        {
            addNewMemberForm.Text = "Add new member";
            addNewMemberForm.saveMemberButton.Visible = true;
            addNewMemberForm.saveChangesButton.Visible = false;
            addNewMemberForm.Show();
        }


        //OTHER FUNCTIONS

        //Updates booksListbox to include all books
        public void UpdateBooksListbox()
        {
            booksListbox.Items.Clear();
            Dictionary<int, Book> books = db.GetBooks();
            foreach (Book book in db.books.Values)
            {
                booksListbox.Items.Add(book);
            }
        }

        public void UpdateAuthorsListBox()
        {
            authorsListbox.Items.Clear();
            Dictionary<int, Author> authors = db.GetAuthors();
            foreach (var author in authors.Values)
            {
                authorsListbox.Items.Add(author);
            }
        }

        public void UpdateMembersListBox()
        {
            allMembersListbox.Items.Clear();
            Dictionary<int, Member> members = db.GetMembers();
            foreach (var member in members.Values)
            {
                allMembersListbox.Items.Add(member);
            }
        }


        //Adds items to the comboboxes so the user can choose what to filter by
        public void AddGenresToCombobox()
        {
            List<string> distinctGenres = db.GetDistinctGenres();
            genreCombobox.Items.Clear();
            genreCombobox.Items.Add("All genres");
            genreCombobox.Items.AddRange(distinctGenres.ToArray());
        }

        public void AddLanguagesToCombobox()
        {
            List<string> distinctLanguages = db.GetDistinctLanguages();
            languageCombobox.Items.Clear();
            languageCombobox.Items.Add("All languages");
            languageCombobox.Items.AddRange(distinctLanguages.ToArray());
        }

        public void AddAuthorsToCombobox()
        {
            Dictionary<int, Author> distinctAuthors = db.GetAuthors();
            authorCombobox.Items.Clear();
            authorCombobox.Items.Add("All authors");
            authorCombobox.Items.AddRange(distinctAuthors.Values.ToArray());
            addNewBookForm.authorsCombobox.Items.AddRange(distinctAuthors.Values.ToArray());
        }

        public void AddNationalitiesToCombobox()
        {
            List<string> distinctNationalities = db.GetDistinctNationalities();
            nationalityCombobox.Items.Clear();
            nationalityCombobox.Items.Add("All nationalities");
            nationalityCombobox.Items.AddRange(distinctNationalities.ToArray());
        }


        //Return book
        public void ReturnBook(ListBox listbox)
        {
            if (listbox.SelectedItem == null)
            {
                MessageBox.Show("Select a book to return");
            }
            else
            {
                Book selectedBook = (Book)listbox.SelectedItem;
                if (!selectedBook.IsCheckedOut)
                {
                    MessageBox.Show("This book has already been returned");
                }
                else
                {
                    selectedBook.Member.Books.Remove(selectedBook);
                    selectedBook.Member = null;

                    db.connection.Open();

                    string query = "UPDATE books SET member_id = @MemberId, is_checked_out = @IsCheckedOut WHERE book_id = @BookId";

                    MySqlCommand command = new MySqlCommand(query, db.connection);
                    command.Parameters.AddWithValue("@MemberId", null);
                    command.Parameters.AddWithValue("@IsCheckedOut", 0);
                    command.Parameters.AddWithValue("@BookId", selectedBook.BookId);

                    command.ExecuteNonQuery();

                    db.connection.Close();

                    selectedBook.IsCheckedOut = false;
                    MessageBox.Show("Book returned successfully");
                    detailsLabel.Text = selectedBook.DisplayDetailsString();
                    checkedOutCheckbox.Checked = false;

                    memberBooksListbox.Items.Remove(selectedBook);
                    UpdateBooksListbox();
                }
            }
        }
    }
}
