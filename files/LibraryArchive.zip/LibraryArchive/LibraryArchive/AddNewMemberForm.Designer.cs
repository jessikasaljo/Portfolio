﻿namespace LibraryArchive
{
    partial class AddNewMemberForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewMemberForm));
            label3 = new Label();
            pictureBox1 = new PictureBox();
            firstnameTextbox = new TextBox();
            firstnameLabel = new Label();
            lastnameTextbox = new TextBox();
            lastnameLabel = new Label();
            saveChangesButton = new Button();
            saveMemberButton = new Button();
            emailTextbox = new TextBox();
            emailLabel = new Label();
            phonenumberTextbox = new TextBox();
            phonenumberLabel = new Label();
            addressTextbox = new TextBox();
            addressLabel = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(81, 15);
            label3.Name = "label3";
            label3.Size = new Size(311, 47);
            label3.TabIndex = 24;
            label3.Text = "Library Archive";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Books_icon;
            pictureBox1.Location = new Point(8, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(67, 62);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            // 
            // firstnameTextbox
            // 
            firstnameTextbox.BorderStyle = BorderStyle.FixedSingle;
            firstnameTextbox.Location = new Point(26, 135);
            firstnameTextbox.Name = "firstnameTextbox";
            firstnameTextbox.Size = new Size(171, 26);
            firstnameTextbox.TabIndex = 26;
            // 
            // firstnameLabel
            // 
            firstnameLabel.AutoSize = true;
            firstnameLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            firstnameLabel.Location = new Point(26, 114);
            firstnameLabel.Name = "firstnameLabel";
            firstnameLabel.Size = new Size(81, 18);
            firstnameLabel.TabIndex = 25;
            firstnameLabel.Text = "First name";
            // 
            // lastnameTextbox
            // 
            lastnameTextbox.BorderStyle = BorderStyle.FixedSingle;
            lastnameTextbox.Location = new Point(26, 232);
            lastnameTextbox.Name = "lastnameTextbox";
            lastnameTextbox.Size = new Size(171, 26);
            lastnameTextbox.TabIndex = 28;
            // 
            // lastnameLabel
            // 
            lastnameLabel.AutoSize = true;
            lastnameLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lastnameLabel.Location = new Point(26, 211);
            lastnameLabel.Name = "lastnameLabel";
            lastnameLabel.Size = new Size(82, 18);
            lastnameLabel.TabIndex = 27;
            lastnameLabel.Text = "Last name";
            // 
            // saveChangesButton
            // 
            saveChangesButton.FlatStyle = FlatStyle.System;
            saveChangesButton.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            saveChangesButton.Location = new Point(213, 402);
            saveChangesButton.Name = "saveChangesButton";
            saveChangesButton.Size = new Size(130, 29);
            saveChangesButton.TabIndex = 29;
            saveChangesButton.Text = "Save changes";
            saveChangesButton.UseVisualStyleBackColor = true;
            saveChangesButton.Visible = false;
            saveChangesButton.Click += saveChangesButton_Click;
            // 
            // saveMemberButton
            // 
            saveMemberButton.FlatStyle = FlatStyle.System;
            saveMemberButton.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            saveMemberButton.Location = new Point(213, 402);
            saveMemberButton.Name = "saveMemberButton";
            saveMemberButton.Size = new Size(130, 29);
            saveMemberButton.TabIndex = 31;
            saveMemberButton.Text = "Save member";
            saveMemberButton.UseVisualStyleBackColor = true;
            saveMemberButton.Click += saveMemberButton_Click;
            // 
            // emailTextbox
            // 
            emailTextbox.BorderStyle = BorderStyle.FixedSingle;
            emailTextbox.Location = new Point(26, 330);
            emailTextbox.Name = "emailTextbox";
            emailTextbox.PlaceholderText = "name@mail.com";
            emailTextbox.Size = new Size(214, 26);
            emailTextbox.TabIndex = 33;
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            emailLabel.Location = new Point(26, 309);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new Size(48, 18);
            emailLabel.TabIndex = 32;
            emailLabel.Text = "Email";
            // 
            // phonenumberTextbox
            // 
            phonenumberTextbox.BorderStyle = BorderStyle.FixedSingle;
            phonenumberTextbox.Location = new Point(344, 135);
            phonenumberTextbox.Name = "phonenumberTextbox";
            phonenumberTextbox.PlaceholderText = "0700-123456";
            phonenumberTextbox.Size = new Size(171, 26);
            phonenumberTextbox.TabIndex = 35;
            // 
            // phonenumberLabel
            // 
            phonenumberLabel.AutoSize = true;
            phonenumberLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            phonenumberLabel.Location = new Point(344, 114);
            phonenumberLabel.Name = "phonenumberLabel";
            phonenumberLabel.Size = new Size(115, 18);
            phonenumberLabel.TabIndex = 34;
            phonenumberLabel.Text = "Phone number";
            // 
            // addressTextbox
            // 
            addressTextbox.BorderStyle = BorderStyle.FixedSingle;
            addressTextbox.Location = new Point(345, 232);
            addressTextbox.Name = "addressTextbox";
            addressTextbox.PlaceholderText = "Storgatan 1";
            addressTextbox.Size = new Size(214, 26);
            addressTextbox.TabIndex = 37;
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addressLabel.Location = new Point(345, 211);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new Size(66, 18);
            addressLabel.TabIndex = 36;
            addressLabel.Text = "Address";
            // 
            // AddNewMemberForm
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Snow;
            ClientSize = new Size(589, 474);
            Controls.Add(addressTextbox);
            Controls.Add(addressLabel);
            Controls.Add(phonenumberTextbox);
            Controls.Add(phonenumberLabel);
            Controls.Add(emailTextbox);
            Controls.Add(emailLabel);
            Controls.Add(saveMemberButton);
            Controls.Add(saveChangesButton);
            Controls.Add(lastnameTextbox);
            Controls.Add(lastnameLabel);
            Controls.Add(firstnameTextbox);
            Controls.Add(firstnameLabel);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddNewMemberForm";
            Text = "Add new member";
            FormClosing += AddNewMemberForm_FormClosing;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private PictureBox pictureBox1;
        public TextBox firstnameTextbox;
        private Label firstnameLabel;
        public TextBox lastnameTextbox;
        private Label lastnameLabel;
        public Button saveChangesButton;
        public TextBox emailTextbox;
        private Label emailLabel;
        public TextBox phonenumberTextbox;
        private Label phonenumberLabel;
        public TextBox addressTextbox;
        private Label addressLabel;
        public Button saveMemberButton;
    }
}