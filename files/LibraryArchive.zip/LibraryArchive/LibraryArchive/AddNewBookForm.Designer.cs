﻿namespace LibraryArchive
{
    partial class AddNewBookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewBookForm));
            saveBookButton = new Button();
            bookTitleLabel = new Label();
            authorsLabel = new Label();
            genreLabel = new Label();
            pagesLabel = new Label();
            publicationLabel = new Label();
            languageLabel = new Label();
            titleTextbox = new TextBox();
            languageTextbox = new TextBox();
            genreTextbox = new TextBox();
            pagesNumeric = new NumericUpDown();
            publicationYearNumeric = new NumericUpDown();
            authorsCombobox = new ComboBox();
            label1 = new Label();
            addNewAuthorButton = new Button();
            authorsListbox = new ListBox();
            removeAuthorButton = new Button();
            label2 = new Label();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            saveChangesButton = new Button();
            ((System.ComponentModel.ISupportInitialize)pagesNumeric).BeginInit();
            ((System.ComponentModel.ISupportInitialize)publicationYearNumeric).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // saveBookButton
            // 
            saveBookButton.BackColor = SystemColors.Window;
            saveBookButton.FlatStyle = FlatStyle.System;
            saveBookButton.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            saveBookButton.Location = new Point(288, 548);
            saveBookButton.Name = "saveBookButton";
            saveBookButton.Size = new Size(176, 29);
            saveBookButton.TabIndex = 0;
            saveBookButton.Text = "Save book to archive";
            saveBookButton.UseVisualStyleBackColor = false;
            saveBookButton.Visible = false;
            saveBookButton.Click += saveBookButton_Click;
            // 
            // bookTitleLabel
            // 
            bookTitleLabel.AutoSize = true;
            bookTitleLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bookTitleLabel.Location = new Point(57, 121);
            bookTitleLabel.Name = "bookTitleLabel";
            bookTitleLabel.Size = new Size(76, 18);
            bookTitleLabel.TabIndex = 1;
            bookTitleLabel.Text = "Book title";
            // 
            // authorsLabel
            // 
            authorsLabel.AutoSize = true;
            authorsLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            authorsLabel.Location = new Point(57, 195);
            authorsLabel.Name = "authorsLabel";
            authorsLabel.Size = new Size(74, 18);
            authorsLabel.TabIndex = 2;
            authorsLabel.Text = "Author(s)";
            // 
            // genreLabel
            // 
            genreLabel.AutoSize = true;
            genreLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            genreLabel.Location = new Point(501, 121);
            genreLabel.Name = "genreLabel";
            genreLabel.Size = new Size(55, 18);
            genreLabel.TabIndex = 3;
            genreLabel.Text = "Genre";
            // 
            // pagesLabel
            // 
            pagesLabel.AutoSize = true;
            pagesLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            pagesLabel.Location = new Point(501, 277);
            pagesLabel.Name = "pagesLabel";
            pagesLabel.Size = new Size(52, 18);
            pagesLabel.TabIndex = 4;
            pagesLabel.Text = "Pages";
            // 
            // publicationLabel
            // 
            publicationLabel.AutoSize = true;
            publicationLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            publicationLabel.Location = new Point(501, 351);
            publicationLabel.Name = "publicationLabel";
            publicationLabel.Size = new Size(128, 18);
            publicationLabel.TabIndex = 5;
            publicationLabel.Text = "Publication year";
            // 
            // languageLabel
            // 
            languageLabel.AutoSize = true;
            languageLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            languageLabel.Location = new Point(501, 195);
            languageLabel.Name = "languageLabel";
            languageLabel.Size = new Size(83, 18);
            languageLabel.TabIndex = 7;
            languageLabel.Text = "Language";
            // 
            // titleTextbox
            // 
            titleTextbox.BorderStyle = BorderStyle.FixedSingle;
            titleTextbox.Location = new Point(57, 142);
            titleTextbox.Name = "titleTextbox";
            titleTextbox.Size = new Size(280, 26);
            titleTextbox.TabIndex = 8;
            // 
            // languageTextbox
            // 
            languageTextbox.BorderStyle = BorderStyle.FixedSingle;
            languageTextbox.Location = new Point(501, 218);
            languageTextbox.Name = "languageTextbox";
            languageTextbox.Size = new Size(207, 26);
            languageTextbox.TabIndex = 10;
            // 
            // genreTextbox
            // 
            genreTextbox.BorderStyle = BorderStyle.FixedSingle;
            genreTextbox.Location = new Point(501, 142);
            genreTextbox.Name = "genreTextbox";
            genreTextbox.Size = new Size(207, 26);
            genreTextbox.TabIndex = 12;
            // 
            // pagesNumeric
            // 
            pagesNumeric.BorderStyle = BorderStyle.FixedSingle;
            pagesNumeric.Location = new Point(501, 298);
            pagesNumeric.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            pagesNumeric.Name = "pagesNumeric";
            pagesNumeric.Size = new Size(68, 26);
            pagesNumeric.TabIndex = 13;
            // 
            // publicationYearNumeric
            // 
            publicationYearNumeric.BorderStyle = BorderStyle.FixedSingle;
            publicationYearNumeric.Location = new Point(501, 372);
            publicationYearNumeric.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            publicationYearNumeric.Name = "publicationYearNumeric";
            publicationYearNumeric.Size = new Size(68, 26);
            publicationYearNumeric.TabIndex = 14;
            // 
            // authorsCombobox
            // 
            authorsCombobox.FormattingEnabled = true;
            authorsCombobox.Location = new Point(57, 216);
            authorsCombobox.Name = "authorsCombobox";
            authorsCombobox.Size = new Size(278, 28);
            authorsCombobox.Sorted = true;
            authorsCombobox.TabIndex = 15;
            authorsCombobox.Text = "Authors";
            authorsCombobox.SelectedIndexChanged += authorsCombobox_SelectedIndexChanged_1;
            authorsCombobox.KeyPress += authorsCombobox_KeyPress;
            // 
            // label1
            // 
            label1.AutoEllipsis = true;
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(57, 381);
            label1.Name = "label1";
            label1.Size = new Size(375, 20);
            label1.TabIndex = 16;
            label1.Text = "Author not in drop-down list? Add new author first:";
            // 
            // addNewAuthorButton
            // 
            addNewAuthorButton.BackColor = SystemColors.Window;
            addNewAuthorButton.FlatStyle = FlatStyle.System;
            addNewAuthorButton.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addNewAuthorButton.Location = new Point(57, 406);
            addNewAuthorButton.Name = "addNewAuthorButton";
            addNewAuthorButton.Size = new Size(130, 29);
            addNewAuthorButton.TabIndex = 17;
            addNewAuthorButton.Text = "Add new author";
            addNewAuthorButton.UseVisualStyleBackColor = false;
            addNewAuthorButton.Click += addNewAuthorButton_Click;
            // 
            // authorsListbox
            // 
            authorsListbox.FormattingEnabled = true;
            authorsListbox.Location = new Point(57, 250);
            authorsListbox.Name = "authorsListbox";
            authorsListbox.Size = new Size(280, 104);
            authorsListbox.Sorted = true;
            authorsListbox.TabIndex = 18;
            // 
            // removeAuthorButton
            // 
            removeAuthorButton.BackColor = SystemColors.Window;
            removeAuthorButton.FlatStyle = FlatStyle.System;
            removeAuthorButton.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            removeAuthorButton.Location = new Point(57, 484);
            removeAuthorButton.Name = "removeAuthorButton";
            removeAuthorButton.Size = new Size(308, 29);
            removeAuthorButton.TabIndex = 19;
            removeAuthorButton.Text = "Remove selected author from this book";
            removeAuthorButton.UseVisualStyleBackColor = false;
            removeAuthorButton.Click += removeAuthorButton_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(57, 461);
            label2.Name = "label2";
            label2.Size = new Size(201, 20);
            label2.TabIndex = 20;
            label2.Text = "Added the wrong author?";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(81, 15);
            label3.Name = "label3";
            label3.Size = new Size(311, 47);
            label3.TabIndex = 22;
            label3.Text = "Library Archive";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Books_icon;
            pictureBox1.Location = new Point(8, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(67, 62);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 21;
            pictureBox1.TabStop = false;
            // 
            // saveChangesButton
            // 
            saveChangesButton.BackColor = SystemColors.Window;
            saveChangesButton.FlatStyle = FlatStyle.System;
            saveChangesButton.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            saveChangesButton.Location = new Point(288, 548);
            saveChangesButton.Name = "saveChangesButton";
            saveChangesButton.Size = new Size(176, 29);
            saveChangesButton.TabIndex = 23;
            saveChangesButton.Text = "Save changes";
            saveChangesButton.UseVisualStyleBackColor = false;
            saveChangesButton.Visible = false;
            saveChangesButton.Click += saveChangesButton_Click;
            // 
            // AddNewBookForm
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Snow;
            ClientSize = new Size(763, 621);
            Controls.Add(saveChangesButton);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(removeAuthorButton);
            Controls.Add(authorsListbox);
            Controls.Add(addNewAuthorButton);
            Controls.Add(label1);
            Controls.Add(authorsCombobox);
            Controls.Add(publicationYearNumeric);
            Controls.Add(pagesNumeric);
            Controls.Add(genreTextbox);
            Controls.Add(languageTextbox);
            Controls.Add(titleTextbox);
            Controls.Add(languageLabel);
            Controls.Add(publicationLabel);
            Controls.Add(pagesLabel);
            Controls.Add(genreLabel);
            Controls.Add(authorsLabel);
            Controls.Add(bookTitleLabel);
            Controls.Add(saveBookButton);
            Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddNewBookForm";
            Text = "Add new book";
            FormClosing += AddNewBookForm_FormClosing;
            ((System.ComponentModel.ISupportInitialize)pagesNumeric).EndInit();
            ((System.ComponentModel.ISupportInitialize)publicationYearNumeric).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label bookTitleLabel;
        private Label authorsLabel;
        private Label genreLabel;
        private Label pagesLabel;
        private Label publicationLabel;
        private Label languageLabel;
        private Label label1;
        private Button addNewAuthorButton;
        public ComboBox authorsCombobox;
        private Button removeAuthorButton;
        private Label label2;
        private Label label3;
        private PictureBox pictureBox1;
        public TextBox titleTextbox;
        public TextBox languageTextbox;
        public TextBox genreTextbox;
        public NumericUpDown pagesNumeric;
        public NumericUpDown publicationYearNumeric;
        public ListBox authorsListbox;
        public Button saveBookButton;
        public Button saveChangesButton;
    }
}