﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace LibraryArchive
{
    public class DatabaseConnection
    {
        //Connection info
        string server = "localhost";
        string database = "library_archive";
        string username = "mainUser";
        string password = "password123";
        string connectionString;
        public MySqlConnection connection;


        //Other fields
        public Dictionary<int, Book> books = new Dictionary<int, Book>();
        public Dictionary<int, Author> authors = new Dictionary<int, Author>();
        public Dictionary<int, Member> members = new Dictionary<int, Member>();
        public MainMenu mainMenu;


        //Constructor
        public DatabaseConnection()
        {
            connectionString =
                "SERVER=" + server + ";" +
                "DATABASE=" + database + ";" +
                "UID=" + username + ";" +
                "PASSWORD=" + password + ";";

            connection = new MySqlConnection(connectionString);
        }


        //Gets tables and info from database
        public Dictionary<int, Member> GetMembers()
        {
            Dictionary<int, Member> members = new Dictionary<int, Member>();

            connection.Open();
            string query = "SELECT * FROM members;";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Member newMember = new Member(
                                  (string)reader["firstname"],
                                  (string)reader["lastname"],
                                  (string)reader["email"],
                                  (string)reader["phone_number"],
                                  (string)reader["address"],
                                  (int)reader["member_id"],
                                  (DateTime)reader["registration_date"]);

                members.Add(newMember.MemberId, newMember);
            }

            connection.Close();
            return members;
        }

        public Dictionary<int, Book> GetBooks()
        {
            connection.Open();
            string query = "SELECT * FROM books;";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                int bookId = (int)reader["book_id"];
                string title = (string)reader["title"];
                List<Author> authors = GetAuthorsForBook(bookId);
                string genre = (string)reader["genre"];
                int pageCount = (int)reader["page_count"];
                short publicationYear = (short)reader["publication_year"];
                string language = (string)reader["language"];
                bool isCheckedOut = (bool)reader["is_checked_out"];
                int? memberId = reader["member_id"] != DBNull.Value ? (int)reader["member_id"] : null;
                Member member = GetMemberForBook(bookId);

                if (books.ContainsKey(bookId))
                {
                    Book existingBook = books[bookId];
                    existingBook.Title = title;
                    existingBook.Authors = authors;
                    existingBook.Genre = genre;
                    existingBook.PageCount = pageCount;
                    existingBook.PublicationYear = publicationYear;
                    existingBook.Language = language;
                    existingBook.IsCheckedOut = isCheckedOut;
                    existingBook.Member = member;
                }
                else
                {
                    Book newBook = new Book(bookId, title, authors, genre, pageCount, publicationYear, language, isCheckedOut, member);
                    books.Add(newBook.BookId, newBook);
                }
            }

            connection.Close();
            return books;
        }

        public List<Author> GetAuthorsForBook(int bookId)
        {
            List<Author> bookAuthors = new List<Author>();

            string query = "SELECT authors.* FROM authors " +
                           "JOIN author_books ON authors.author_id = author_books.author_id " +
                           "WHERE author_books.book_id = @BookId;";

            MySqlConnection newConnection = new MySqlConnection(connectionString);
            newConnection.Open();
            MySqlCommand command = new MySqlCommand(query, newConnection);
            command.Parameters.AddWithValue("@BookId", bookId);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Author author = new Author(
                      (int)reader["author_id"],
                      (string)reader["firstname"],
                      (string)reader["lastname"],
                      (string)reader["nationality"]);

                bookAuthors.Add(author);
            }

            newConnection.Close();
            return bookAuthors;
        }

        public List<Book> GetBooksForAuthor(int authorId)
        {
            List<Book> booksForAuthor = new List<Book>();

            string query = "SELECT books.* FROM books " +
                           "JOIN author_books ON books.book_id = author_books.book_id " +
                           "WHERE author_books.author_id = @AuthorId;";

            MySqlConnection newConnection = new MySqlConnection(connectionString);
            newConnection.Open();
            MySqlCommand command = new MySqlCommand(query, newConnection);
            command.Parameters.AddWithValue("@AuthorId", authorId);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Book book = new Book(
                    (int)reader["book_id"],
                    (string)reader["title"],
                    (string)reader["genre"],
                    (int)reader["page_count"],
                    (short)reader["publication_year"],
                    (string)reader["language"]
                );
                booksForAuthor.Add(book);
            }

            newConnection.Close();
            return booksForAuthor;
        }

        public Dictionary<int, Author> GetAuthors()
        {
            Dictionary<int, Author> authors = new Dictionary<int, Author>();
            
            string query = "SELECT DISTINCT * FROM authors;";

            MySqlConnection newConnection = new MySqlConnection(connectionString);
            newConnection.Open();
            MySqlCommand command = new MySqlCommand(query, newConnection);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Author newAuthor = new Author(
                                  (int)reader["author_id"],
                                  (string)reader["firstname"],
                                  (string)reader["lastname"],
                                  (string)reader["nationality"]);

                authors.Add(newAuthor.AuthorId, newAuthor);
            }

            newConnection.Close();

            return authors;
        }


        public Member GetMemberForBook(int bookId)
        {
            string query = "SELECT members.* FROM members " +
                           "JOIN books ON members.member_id = books.member_id " +
                           "WHERE books.book_id = @BookId;";

            MySqlConnection newConnection = new MySqlConnection(connectionString);
            newConnection.Open();
            MySqlCommand command = new MySqlCommand(query, newConnection);
            command.Parameters.AddWithValue("@BookId", bookId);

            MySqlDataReader reader = command.ExecuteReader();

            Member member = null;

            if (reader.Read())
            {
                member = new Member(
                        (string)reader["firstname"],
                        (string)reader["lastname"],
                        (string)reader["email"],
                        (string)reader["phone_number"],
                        (string)reader["address"],
                        (int)reader["member_id"],
                        (DateTime)reader["registration_date"]);
            }

            newConnection.Close();
            return member;
        }

        public List<Book> GetBooksForMember(int memberId)
        {
            List<Book> booksForMember = new List<Book>();

            string query = "SELECT * FROM books " +
                           "WHERE member_id = @MemberId;";

            MySqlConnection newConnection = new MySqlConnection(connectionString);
            newConnection.Open();
            MySqlCommand command = new MySqlCommand(query, newConnection);
            command.Parameters.AddWithValue("@MemberId", memberId);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Book book = new Book(
                    (int)reader["book_id"],
                    (string)reader["title"],
                    (string)reader["genre"],
                    (int)reader["page_count"],
                    (short)reader["publication_year"],
                    (string)reader["language"]
                );
                
                bool isCheckedOut = (bool)reader["is_checked_out"];
                book.IsCheckedOut = isCheckedOut;

                if (isCheckedOut)
                {
                    int memberForBookId = (int)reader["member_id"];
                    Member memberForBook = GetMemberForBook(book.BookId);
                    book.Member = memberForBook;
                }

                book.Authors = GetAuthorsForBook(book.BookId);
                booksForMember.Add(book);

            }

            newConnection.Close();
            return booksForMember;
        }


        //Gets specific columns from database
        public List<string> GetDistinctGenres()
        {
            List<string> genres = new List<string>();

            connection.Open();
            string query = "SELECT DISTINCT genre FROM books;";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                string genre = (string)reader["genre"];
                genres.Add(genre);
            }

            connection.Close();
            return genres;
        }

        public List<string> GetDistinctLanguages()
        {
            List<string> languages = new List<string>();

            connection.Open();
            string query = "SELECT DISTINCT language FROM books;";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                string language = (string)reader["language"];
                languages.Add(language);
            }

            connection.Close();
            return languages;
        }

        public List<string> GetDistinctNationalities()
        {
            List<string> nationalities = new List<string>();

            connection.Open();
            string query = "SELECT DISTINCT nationality FROM authors;";
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                string nationality = (string)reader["nationality"];
                nationalities.Add(nationality);
            }

            connection.Close();
            return nationalities;
        }


        //Saves to database
        public Book AddBook(string title, string genre, int pageCount, short publicationYear, string language, bool isCheckedOut, List<Author> authorsForBook)
        {
            MySqlConnection newConnection = new MySqlConnection(connectionString);
            newConnection.Open();

            string query = "INSERT INTO books VALUES(DEFAULT, @Title, @Genre, @PageCount, @PublicationYear, @Language, @MemberId, @IsCheckedOut)";

            MySqlCommand command = new MySqlCommand(query, newConnection);
            command.Parameters.AddWithValue("@Title", title);
            command.Parameters.AddWithValue("@Genre", genre);
            command.Parameters.AddWithValue("@PageCount", pageCount);
            command.Parameters.AddWithValue("@PublicationYear", publicationYear);
            command.Parameters.AddWithValue("@Language", language);
            command.Parameters.AddWithValue("@MemberId", null);
            command.Parameters.AddWithValue("@IsCheckedOut", isCheckedOut ? 1 : 0);

            command.ExecuteNonQuery();

            query = "SELECT MAX(book_id) AS id FROM books;";
            command = new MySqlCommand(query, newConnection);
            MySqlDataReader reader = command.ExecuteReader();

            reader.Read();
            int bookId = (int)reader["id"];
            reader.Close();

            Book newBook = new Book(bookId, title, genre, pageCount, publicationYear, language);

            foreach (Author author in authorsForBook) 
            {
                query = "INSERT INTO author_books VALUES(@AuthorId, @BookId)";
                command = new MySqlCommand(query, newConnection);
                command.Parameters.AddWithValue("@AuthorId", author.AuthorId);
                command.Parameters.AddWithValue("@BookId", bookId);

                command.ExecuteNonQuery();

                author.Books.Add(newBook);
            }

            newConnection.Close();
            return newBook;
        }

        public void EditBook(int bookId, string title, string genre, int pageCount, short publicationYear, string language, List<Author> authorsForBook)
        {
            Book existingBook = books[bookId];

            existingBook.Title = title;
            existingBook.Genre = genre;
            existingBook.PageCount = pageCount;
            existingBook.PublicationYear = publicationYear;
            existingBook.Language = language;

            existingBook.Authors.Clear();
            existingBook.Authors.AddRange(authorsForBook);

            books[bookId] = existingBook;

            MySqlConnection newConnection = new MySqlConnection(connectionString);
            newConnection.Open();

            MySqlCommand command = new MySqlCommand("update_book", newConnection);
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@in_book_id", bookId);
            command.Parameters.AddWithValue("@in_title", title);
            command.Parameters.AddWithValue("@in_genre", genre);
            command.Parameters.AddWithValue("@in_page_count", pageCount);
            command.Parameters.AddWithValue("@in_publication_year", publicationYear);
            command.Parameters.AddWithValue("@in_language", language);
            command.ExecuteNonQuery();

            string query = "DELETE FROM author_books WHERE book_id = @BookId";
            command = new MySqlCommand(query, newConnection);
            command.Parameters.AddWithValue("@BookId", bookId);
            command.ExecuteNonQuery();

            foreach (Author author in authorsForBook)
            {
                query = "INSERT INTO author_books VALUES(@AuthorId, @BookId)";
                command = new MySqlCommand(query, newConnection);
                command.Parameters.AddWithValue("@AuthorId", author.AuthorId);
                command.Parameters.AddWithValue("@BookId", bookId);
                command.ExecuteNonQuery();
            }

            newConnection.Close();
        }

        public void RemoveBook(Book book)
        {
            connection.Open();

            string query = "DELETE FROM author_books WHERE book_id = @BookId";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@BookId", book.BookId);
            command.ExecuteNonQuery();

            query = "DELETE FROM books WHERE book_id = @BookId";
            MySqlCommand newCommand = new MySqlCommand(query, connection);
            newCommand.Parameters.AddWithValue("@BookId", book.BookId);
            newCommand.ExecuteNonQuery();

            connection.Close();

            authors.Remove(book.BookId);
        }

        public Author AddAuthor(string firstname, string lastname, string nationality)
        {
            connection.Open();

            string query = "INSERT INTO authors VALUES(DEFAULT, @Firstname, @Lastname, @Nationality)";

            MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Firstname", firstname);
            command.Parameters.AddWithValue("@Lastname", lastname);
            command.Parameters.AddWithValue("@Nationality", nationality);

            command.ExecuteNonQuery();

            query = "SELECT MAX(author_id) AS id FROM authors;";
            command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();

            reader.Read();
            int authorId = (int)reader["id"];
            reader.Close();

            Author newAuthor = new Author(authorId, firstname, lastname, nationality);
            authors.Add(authorId, newAuthor);

            connection.Close();

            return newAuthor;
        }

        public void EditAuthor(int authorId, string firstname, string lastname, string nationality)
        {
            Dictionary<int, Author> authors = GetAuthors();

            Author existingAuthor = authors[authorId];
            existingAuthor.Firstname = firstname;
            existingAuthor.Lastname = lastname;
            existingAuthor.Nationality = nationality;

            MySqlConnection newConnection = new MySqlConnection(connectionString);
            newConnection.Open();

            string query = "UPDATE authors SET firstname = @Firstname, lastname = @Lastname, nationality = @Nationality WHERE author_id = @AuthorId";

            MySqlCommand command = new MySqlCommand(query, newConnection);

            command.Parameters.AddWithValue("@AuthorId", authorId);
            command.Parameters.AddWithValue("@Firstname", firstname);
            command.Parameters.AddWithValue("@Lastname", lastname);
            command.Parameters.AddWithValue("@Nationality", nationality);
            command.ExecuteNonQuery();

            newConnection.Close();
        }

        public void RemoveAuthor(Author author)
        {
            connection.Open();

            string query = "DELETE FROM authors WHERE author_id = @AuthorId";

            MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@AuthorId", author.AuthorId);
            command.ExecuteNonQuery();

            connection.Close();

            authors.Remove(author.AuthorId);
        }

        public string GetMemberInfo(int memberId)
        {
            connection.Open();

            string query = "SELECT * FROM MemberInfoView WHERE member_id = @memberId";

            MySqlCommand command = new MySqlCommand(query, connection);               
            command.Parameters.AddWithValue("@memberId", memberId);

            MySqlDataReader reader = command.ExecuteReader();
                   
            if (reader.Read())
            {
                string email = (string)reader["email"];
                string phoneNumber = (string)reader["phone_number"];
                string address = (string)reader["address"];
                DateTime registrationDate = (DateTime)reader["registration_date"];
                int checkedOutBooksCount = Convert.ToInt32(reader["books_checked_out"]);

                string displayString = "Email: " + email + "\r\n\r\n" +
                                        "Phone number: " + phoneNumber + "\r\n\r\n" +
                                        "Address: " + address + "\r\n\n" +
                                        "Library member since: "+ registrationDate.ToString("yyyy-MM-dd") + "\r\n\r\n" +
                                        "Checked out books: " + checkedOutBooksCount;
                connection.Close();
                return displayString;
            }
            connection.Close();
            return "";
        }


        public void RemoveMember(Member member)
        {
            using (MySqlConnection newConnection = new MySqlConnection(connectionString))
            {
                newConnection.Open();

                string query = "DELETE FROM members WHERE member_id = @MemberId";

                using (MySqlCommand command = new MySqlCommand(query, newConnection))
                {
                    command.Parameters.AddWithValue("@MemberId", member.MemberId);
                    command.ExecuteNonQuery();
                }

                members.Remove(member.MemberId);
            }
        }

        public Member AddMember(string firstname, string lastname, string email, string phonenumber, string address)
        {
            connection.Open();

            string query = "INSERT INTO members VALUES(DEFAULT, @Firstname, @Lastname, @Email, @Phonenumber, @Address, @RegistrationDate)";
            DateTime registrationDate = DateTime.Now;

            MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Firstname", firstname);
            command.Parameters.AddWithValue("@Lastname", lastname);
            command.Parameters.AddWithValue("@Email", email);
            command.Parameters.AddWithValue("@Phonenumber", phonenumber);
            command.Parameters.AddWithValue("@Address", address);
            command.Parameters.AddWithValue("RegistrationDate", registrationDate);

            command.ExecuteNonQuery();

            query = "SELECT MAX(member_id) AS id FROM members;";
            command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();

            reader.Read();
            int memberId = (int)reader["id"];
            reader.Close();

            Member newMember = new Member(firstname, lastname, email, phonenumber, address, memberId, registrationDate);
            members.Add(memberId, newMember);

            connection.Close();

            return newMember;
        }

        public void EditMember(int memberId, string firstname, string lastname, string email, string phonenumber, string address)
        {
            Dictionary<int, Member> members = GetMembers();

            Member existingMember = members[memberId];
            existingMember.Firstname = firstname;
            existingMember.Lastname = lastname;
            existingMember.Email = email;
            existingMember.PhoneNumber = phonenumber;
            existingMember.Address = address;

            connection.Open();

            string query = "UPDATE members SET firstname = @Firstname, lastname = @Lastname, email = @Email, phone_number = @Phonenumber, address = @Address WHERE member_id = @MemberId";

            MySqlCommand command = new MySqlCommand(query, connection);

            command.Parameters.AddWithValue("@MemberId", memberId);
            command.Parameters.AddWithValue("@Firstname", firstname);
            command.Parameters.AddWithValue("@Lastname", lastname);
            command.Parameters.AddWithValue("@Email", email);
            command.Parameters.AddWithValue("@Phonenumber", phonenumber);
            command.Parameters.AddWithValue("@Address", address);
            command.ExecuteNonQuery();

            connection.Close();
        }


        //Search function
        public List<Book> SearchBooksByTitle(string searchTerm)
        {
            List<Book> matchingBooks = new List<Book>();

            connection.Open();

            string query = "CALL search_books_by_title(@SearchTerm)";
            MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@SearchTerm", searchTerm);

            MySqlDataReader reader = command.ExecuteReader();
                
                while (reader.Read())
                {
                    Book book = new Book(
                                (int)reader["book_id"],
                                (string)reader["title"],
                                (string)reader["genre"],
                                (int)reader["page_count"],
                                (short)reader["publication_year"],
                                (string)reader["language"]);

                book.Authors = GetAuthorsForBook(book.BookId);               
                book.IsCheckedOut = (bool)reader["is_checked_out"];
                matchingBooks.Add(book);
                }

            connection.Close();
           
            return matchingBooks;
        }


    }
}
