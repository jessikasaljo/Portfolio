﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryArchive
{
    public class Member
    {
        //Fields
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public int MemberId { get; set; }
        public DateTime RegistrationDate { get; set;}
        public List<Book> Books { get; set;}


        //Constructor
        public Member(string firstname, string lastname, string email, string phoneNumber, string address, int memberId, DateTime registrationDate)
        {
            Firstname = firstname;
            Lastname = lastname;
            Email = email;
            PhoneNumber = phoneNumber;
            Address = address;
            MemberId = memberId;
            RegistrationDate = registrationDate;
            Books = new List<Book>();

        }


        //Returns firstname and lastname as a string
        public override string ToString()
        {
            return $"{Firstname} {Lastname}";
        }
    }
}
