﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryArchive
{
    public partial class AddNewMemberForm : Form
    {
        //Fields
        public MainMenu mainMenu;
        public DatabaseConnection db;


        //Constructor
        public AddNewMemberForm()
        {
            InitializeComponent();
        }

        //Saves new member
        private void saveMemberButton_Click(object sender, EventArgs e)
        {
            string firstname = firstnameTextbox.Text.Trim();
            string lastname = lastnameTextbox.Text.Trim();
            string email = emailTextbox.Text.Trim();
            string phonenumber = phonenumberTextbox.Text.Trim();
            string address = addressTextbox.Text.Trim();


            if (!string.IsNullOrWhiteSpace(firstname) &&
                !string.IsNullOrWhiteSpace(lastname) &&
                !string.IsNullOrWhiteSpace(email) &&
                !string.IsNullOrWhiteSpace(phonenumber) &&
                !string.IsNullOrWhiteSpace(address))
            {
                db.AddMember(firstname, lastname, email, phonenumber, address);

                mainMenu.UpdateMembersListBox();
                Hide();

                MessageBox.Show("Member successfully saved");
            }
            else
            {
                MessageBox.Show("Some fields are empty or invalid");
            }
        }


        //Saves changes made to member
        private void saveChangesButton_Click(object sender, EventArgs e)
        {
            Member memberToEdit = (Member)mainMenu.allMembersListbox.SelectedItem;
            int memberId = memberToEdit.MemberId;
            string firstname = firstnameTextbox.Text.Trim();
            string lastname = lastnameTextbox.Text.Trim();
            string email = emailTextbox.Text.Trim();
            string phonenumber = phonenumberTextbox.Text.Trim();
            string address = addressTextbox.Text.Trim();


            if (!string.IsNullOrWhiteSpace(firstname) &&
                !string.IsNullOrWhiteSpace(lastname) &&
                !string.IsNullOrWhiteSpace(email) &&
                !string.IsNullOrWhiteSpace(phonenumber) &&
                !string.IsNullOrWhiteSpace(address))
            {

                db.EditMember(memberId, firstname, lastname, email, phonenumber, address);

                mainMenu.UpdateMembersListBox();
                mainMenu.memberDetailsLabel.Text = db.GetMemberInfo(memberToEdit.MemberId);

                Hide();
                MessageBox.Show("Changes successfully saved");
            }
            else
            {
                MessageBox.Show("Some fields are empty or invalid");
            }
        }


        //Keeps the form from closing and hides it instead
        private void AddNewMemberForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }
    }
}
