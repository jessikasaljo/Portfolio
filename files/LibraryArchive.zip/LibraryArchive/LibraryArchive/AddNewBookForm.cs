﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryArchive
{
    public partial class AddNewBookForm : Form
    {
        //Fields
        public MainMenu mainMenu;
        public AddNewAuthorForm addNewAuthorForm;
        public DatabaseConnection db;


        //Constructor
        public AddNewBookForm()
        {
            InitializeComponent();
        }


        //EVENT HANDLING

        //Saves new book if information is filled out correctly
        private void saveBookButton_Click(object sender, EventArgs e)
        {
            string title = titleTextbox.Text.Trim();
            string genre = genreTextbox.Text.Trim();
            int pages = (int)pagesNumeric.Value;
            short publicationYear = (short)publicationYearNumeric.Value;
            string language = languageTextbox.Text.Trim();
            List<Author> authorsToAdd = authorsListbox.Items.Cast<Author>().ToList();

            if (!string.IsNullOrWhiteSpace(title) && authorsToAdd != null &&
                !string.IsNullOrWhiteSpace(genre) && !string.IsNullOrWhiteSpace(language) &&
                pages != 0 && publicationYear != 0)
            {
                db.AddBook(title, genre, pages, publicationYear, language, false, authorsToAdd);

                mainMenu.AddLanguagesToCombobox();
                mainMenu.AddGenresToCombobox();
                mainMenu.UpdateBooksListbox();

                MessageBox.Show("Book successfully saved");

                Hide();
            }
            else
            {
                MessageBox.Show("Some fields are empty or invalid");
            }
        }

        private void saveChangesButton_Click(object sender, EventArgs e)
        {
            Book bookToEdit = (Book)mainMenu.booksListbox.SelectedItem;
            int bookId = bookToEdit.BookId;
            string title = titleTextbox.Text.Trim();
            string genre = genreTextbox.Text.Trim();
            int pages = (int)pagesNumeric.Value;
            short publicationYear = (short)publicationYearNumeric.Value;
            string language = languageTextbox.Text.Trim();
            List<Author> authorsToAdd = authorsListbox.Items.Cast<Author>().ToList();

            if (!string.IsNullOrWhiteSpace(title) && authorsToAdd != null &&
                !string.IsNullOrWhiteSpace(genre) && !string.IsNullOrWhiteSpace(language) &&
                pages != 0 && publicationYear != 0)
            {
                foreach (Author author in authorsToAdd)
                {
                    author.RemoveBook(bookToEdit);
                    author.Books.Add(bookToEdit);
                }
                db.EditBook(bookId, title, genre, pages, publicationYear, language, authorsToAdd);

                mainMenu.AddLanguagesToCombobox();
                mainMenu.AddGenresToCombobox();
                mainMenu.UpdateBooksListbox();

                Hide();
                MessageBox.Show("Changes successfully saved");
            }
            else
            {
                MessageBox.Show("Some fields are empty or invalid");
            }
        }


        //Stops user from changing the text in the combobox
        private void authorsCombobox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }


        //Opens form for adding new author if they're not already in the database
        private void addNewAuthorButton_Click(object sender, EventArgs e)
        {
            addNewAuthorForm.Show(); //Funkar inte om man stängt ner rutan och vill lägga till en ny
        }


        //Adds author to the listbox of which authors have written the book
        private void authorsCombobox_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            bool existingAuthor = false;

            foreach (var item in authorsListbox.Items)
            {
                if (item is Author listBoxAuthor && authorsCombobox.SelectedItem is Author comboAuthor)
                {
                    if (listBoxAuthor.Equals(comboAuthor))
                    {
                        existingAuthor = true;
                        break;
                    }
                }
            }

            if (authorsCombobox.SelectedItem is Author selectedAuthor && !existingAuthor)
            {
                authorsListbox.Items.Add(selectedAuthor);
            }
            else
            {
                MessageBox.Show("This author is already added as an author for this book");
            }
        }


        //Removes author from the listbox
        private void removeAuthorButton_Click(object sender, EventArgs e)
        {
            if (authorsListbox.SelectedItem != null)
            {
                authorsListbox.Items.Remove(authorsListbox.SelectedItem);
            }
        }


        //Keeps the form from closing and hides it instead
        private void AddNewBookForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }


        //OTHER FUNCTIONS



    }
}
