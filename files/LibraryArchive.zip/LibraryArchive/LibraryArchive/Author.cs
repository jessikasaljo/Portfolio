﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryArchive
{
    public class Author
    {
        //Fields
        public int AuthorId { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Nationality { get; set; }
        public List<Book> Books { get; set; }


        //Constructor
        public Author(int authorId, string firstname, string lastname, string nationality)
        {
            AuthorId = authorId;
            Firstname = firstname;
            Lastname = lastname;
            Nationality = nationality;
            Books = new List<Book>();
        }


        //Returns combination of first and last name when displaying the author
        public override string ToString()
        {
            return $"{Firstname} {Lastname}";
        }


        // Checks if two Author objects are equal based on their Firstname and Lastname
        public bool Equals(Author other)
        {
            if (other == null)
                return false;

            return Firstname == other.Firstname && Lastname == other.Lastname;
        }


        //Removes book from author
        public void RemoveBook(Book book)
        {
            Books.Remove(book);
        }
    }
}
