﻿namespace LibraryArchive
{
    partial class AddNewAuthorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewAuthorForm));
            firstnameLabel = new Label();
            lastnameLabel = new Label();
            nationalityLabel = new Label();
            firstnameTextbox = new TextBox();
            lastnameTextbox = new TextBox();
            nationalityTextbox = new TextBox();
            saveAuthorButton = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            saveChangesButton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // firstnameLabel
            // 
            firstnameLabel.AutoSize = true;
            firstnameLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            firstnameLabel.Location = new Point(197, 136);
            firstnameLabel.Name = "firstnameLabel";
            firstnameLabel.Size = new Size(81, 18);
            firstnameLabel.TabIndex = 0;
            firstnameLabel.Text = "First name";
            // 
            // lastnameLabel
            // 
            lastnameLabel.AutoSize = true;
            lastnameLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lastnameLabel.Location = new Point(196, 214);
            lastnameLabel.Name = "lastnameLabel";
            lastnameLabel.Size = new Size(82, 18);
            lastnameLabel.TabIndex = 1;
            lastnameLabel.Text = "Last name";
            // 
            // nationalityLabel
            // 
            nationalityLabel.AutoSize = true;
            nationalityLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nationalityLabel.Location = new Point(197, 291);
            nationalityLabel.Name = "nationalityLabel";
            nationalityLabel.Size = new Size(87, 18);
            nationalityLabel.TabIndex = 2;
            nationalityLabel.Text = "Nationality";
            // 
            // firstnameTextbox
            // 
            firstnameTextbox.BorderStyle = BorderStyle.FixedSingle;
            firstnameTextbox.Location = new Point(197, 157);
            firstnameTextbox.Name = "firstnameTextbox";
            firstnameTextbox.Size = new Size(220, 26);
            firstnameTextbox.TabIndex = 3;
            // 
            // lastnameTextbox
            // 
            lastnameTextbox.BorderStyle = BorderStyle.FixedSingle;
            lastnameTextbox.Location = new Point(196, 235);
            lastnameTextbox.Name = "lastnameTextbox";
            lastnameTextbox.Size = new Size(220, 26);
            lastnameTextbox.TabIndex = 4;
            // 
            // nationalityTextbox
            // 
            nationalityTextbox.BorderStyle = BorderStyle.FixedSingle;
            nationalityTextbox.Location = new Point(196, 312);
            nationalityTextbox.Name = "nationalityTextbox";
            nationalityTextbox.Size = new Size(220, 26);
            nationalityTextbox.TabIndex = 5;
            // 
            // saveAuthorButton
            // 
            saveAuthorButton.FlatStyle = FlatStyle.System;
            saveAuthorButton.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            saveAuthorButton.Location = new Point(232, 374);
            saveAuthorButton.Name = "saveAuthorButton";
            saveAuthorButton.Size = new Size(125, 29);
            saveAuthorButton.TabIndex = 6;
            saveAuthorButton.Text = "Save author";
            saveAuthorButton.UseVisualStyleBackColor = true;
            saveAuthorButton.Click += saveAuthorButton_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Books_icon;
            pictureBox1.Location = new Point(7, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(67, 62);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(80, 15);
            label1.Name = "label1";
            label1.Size = new Size(311, 47);
            label1.TabIndex = 8;
            label1.Text = "Library Archive";
            // 
            // saveChangesButton
            // 
            saveChangesButton.FlatStyle = FlatStyle.System;
            saveChangesButton.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            saveChangesButton.Location = new Point(232, 374);
            saveChangesButton.Name = "saveChangesButton";
            saveChangesButton.Size = new Size(130, 29);
            saveChangesButton.TabIndex = 9;
            saveChangesButton.Text = "Save changes";
            saveChangesButton.UseVisualStyleBackColor = true;
            saveChangesButton.Visible = false;
            saveChangesButton.Click += saveChangesButton_Click;
            // 
            // AddNewAuthorForm
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Snow;
            ClientSize = new Size(608, 463);
            Controls.Add(saveChangesButton);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(saveAuthorButton);
            Controls.Add(nationalityTextbox);
            Controls.Add(lastnameTextbox);
            Controls.Add(firstnameTextbox);
            Controls.Add(nationalityLabel);
            Controls.Add(lastnameLabel);
            Controls.Add(firstnameLabel);
            Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddNewAuthorForm";
            Text = "Add new author";
            FormClosing += AddNewAuthorForm_FormClosing;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label firstnameLabel;
        private Label lastnameLabel;
        private Label nationalityLabel;
        private PictureBox pictureBox1;
        private Label label1;
        public TextBox firstnameTextbox;
        public TextBox lastnameTextbox;
        public TextBox nationalityTextbox;
        public Button saveAuthorButton;
        public Button saveChangesButton;
    }
}