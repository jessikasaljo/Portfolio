﻿namespace LibraryArchive
{
    partial class MainMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            authorsLabel = new Label();
            membersLabel = new Label();
            booksLabel = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            searchIcon = new PictureBox();
            searchTextbox = new TextBox();
            label2 = new Label();
            booksPanel = new Panel();
            chooseMemberPanel = new Panel();
            backToBooksButton = new Button();
            confirmMemberButton = new Button();
            membersListbox = new ListBox();
            chooseMemberLabel = new Label();
            editBookButton = new Button();
            returnButton = new Button();
            checkoutButton = new Button();
            newBookButton = new Button();
            availableBooksCheckbox = new CheckBox();
            checkedOutCheckbox = new CheckBox();
            genreCombobox = new ComboBox();
            authorCombobox = new ComboBox();
            languageCombobox = new ComboBox();
            detailsLabel = new Label();
            booksListbox = new ListBox();
            authorsPanel = new Panel();
            removeAuthorButton = new Button();
            editAuthorButton = new Button();
            addNewAuthorButton = new Button();
            authorDetailsLabel = new Label();
            nationalityCombobox = new ComboBox();
            authorsListbox = new ListBox();
            membersPanel = new Panel();
            addNewMemberButton = new Button();
            removeMemberButton = new Button();
            editMemberButton = new Button();
            returnBookButton = new Button();
            memberBooksListbox = new ListBox();
            libraryMembersLabel = new Label();
            checkedOutBooksLabel = new Label();
            memberDetailsLabel = new Label();
            allMembersListbox = new ListBox();
            removeBookButton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)searchIcon).BeginInit();
            booksPanel.SuspendLayout();
            chooseMemberPanel.SuspendLayout();
            authorsPanel.SuspendLayout();
            membersPanel.SuspendLayout();
            SuspendLayout();
            // 
            // authorsLabel
            // 
            authorsLabel.AutoSize = true;
            authorsLabel.BackColor = Color.Chocolate;
            authorsLabel.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            authorsLabel.ForeColor = Color.Snow;
            authorsLabel.Location = new Point(284, 112);
            authorsLabel.Name = "authorsLabel";
            authorsLabel.Padding = new Padding(100, 10, 100, 10);
            authorsLabel.Size = new Size(283, 43);
            authorsLabel.TabIndex = 3;
            authorsLabel.Text = "Authors";
            authorsLabel.Click += authorsLabel_Click;
            authorsLabel.MouseEnter += authorsLabel_MouseEnter;
            authorsLabel.MouseLeave += authorsLabel_MouseLeave;
            // 
            // membersLabel
            // 
            membersLabel.AutoSize = true;
            membersLabel.BackColor = Color.Peru;
            membersLabel.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            membersLabel.ForeColor = Color.Snow;
            membersLabel.Location = new Point(569, 112);
            membersLabel.Name = "membersLabel";
            membersLabel.Padding = new Padding(88, 10, 88, 10);
            membersLabel.Size = new Size(277, 43);
            membersLabel.TabIndex = 1;
            membersLabel.Text = "Members";
            membersLabel.Click += membersLabel_Click;
            membersLabel.MouseEnter += membersLabel_MouseEnter;
            membersLabel.MouseLeave += membersLabel_MouseLeave;
            // 
            // booksLabel
            // 
            booksLabel.AutoSize = true;
            booksLabel.BackColor = Color.Sienna;
            booksLabel.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            booksLabel.ForeColor = Color.Snow;
            booksLabel.Location = new Point(3, 112);
            booksLabel.Name = "booksLabel";
            booksLabel.Padding = new Padding(105, 10, 105, 10);
            booksLabel.Size = new Size(279, 43);
            booksLabel.TabIndex = 0;
            booksLabel.Text = "Books";
            booksLabel.Click += booksLabel_Click;
            booksLabel.MouseEnter += booksLabel_MouseEnter;
            booksLabel.MouseLeave += booksLabel_MouseLeave;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(81, 15);
            label1.Name = "label1";
            label1.Size = new Size(311, 47);
            label1.TabIndex = 2;
            label1.Text = "Library Archive";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Books_icon;
            pictureBox1.Location = new Point(8, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(67, 62);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // searchIcon
            // 
            searchIcon.BackColor = Color.Snow;
            searchIcon.Image = Properties.Resources.Search_icon;
            searchIcon.Location = new Point(793, 45);
            searchIcon.Name = "searchIcon";
            searchIcon.Size = new Size(44, 32);
            searchIcon.SizeMode = PictureBoxSizeMode.Zoom;
            searchIcon.TabIndex = 4;
            searchIcon.TabStop = false;
            searchIcon.Click += searchIcon_Click;
            // 
            // searchTextbox
            // 
            searchTextbox.BackColor = SystemColors.Window;
            searchTextbox.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            searchTextbox.Location = new Point(474, 45);
            searchTextbox.Name = "searchTextbox";
            searchTextbox.Size = new Size(336, 32);
            searchTextbox.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(474, 15);
            label2.Name = "label2";
            label2.Size = new Size(246, 23);
            label2.TabIndex = 6;
            label2.Text = "Search for books by title";
            // 
            // booksPanel
            // 
            booksPanel.Controls.Add(chooseMemberPanel);
            booksPanel.Controls.Add(removeBookButton);
            booksPanel.Controls.Add(editBookButton);
            booksPanel.Controls.Add(returnButton);
            booksPanel.Controls.Add(checkoutButton);
            booksPanel.Controls.Add(newBookButton);
            booksPanel.Controls.Add(availableBooksCheckbox);
            booksPanel.Controls.Add(checkedOutCheckbox);
            booksPanel.Controls.Add(genreCombobox);
            booksPanel.Controls.Add(authorCombobox);
            booksPanel.Controls.Add(languageCombobox);
            booksPanel.Controls.Add(detailsLabel);
            booksPanel.Controls.Add(booksListbox);
            booksPanel.Location = new Point(8, 179);
            booksPanel.Name = "booksPanel";
            booksPanel.Size = new Size(829, 507);
            booksPanel.TabIndex = 7;
            booksPanel.Visible = false;
            // 
            // chooseMemberPanel
            // 
            chooseMemberPanel.Controls.Add(backToBooksButton);
            chooseMemberPanel.Controls.Add(confirmMemberButton);
            chooseMemberPanel.Controls.Add(membersListbox);
            chooseMemberPanel.Controls.Add(chooseMemberLabel);
            chooseMemberPanel.Location = new Point(3, 6);
            chooseMemberPanel.Name = "chooseMemberPanel";
            chooseMemberPanel.Size = new Size(822, 498);
            chooseMemberPanel.TabIndex = 10;
            chooseMemberPanel.Visible = false;
            // 
            // backToBooksButton
            // 
            backToBooksButton.BackColor = SystemColors.Window;
            backToBooksButton.BackgroundImageLayout = ImageLayout.Zoom;
            backToBooksButton.Location = new Point(25, 3);
            backToBooksButton.Name = "backToBooksButton";
            backToBooksButton.Size = new Size(143, 34);
            backToBooksButton.TabIndex = 3;
            backToBooksButton.Text = "Back to books";
            backToBooksButton.UseVisualStyleBackColor = false;
            backToBooksButton.Click += backToBooksButton_Click;
            // 
            // confirmMemberButton
            // 
            confirmMemberButton.BackColor = SystemColors.Window;
            confirmMemberButton.Location = new Point(349, 298);
            confirmMemberButton.Name = "confirmMemberButton";
            confirmMemberButton.Size = new Size(173, 55);
            confirmMemberButton.TabIndex = 2;
            confirmMemberButton.Text = "Confirm member for checkout";
            confirmMemberButton.UseVisualStyleBackColor = false;
            confirmMemberButton.Click += confirmMemberButton_Click;
            // 
            // membersListbox
            // 
            membersListbox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            membersListbox.FormattingEnabled = true;
            membersListbox.Location = new Point(261, 68);
            membersListbox.Name = "membersListbox";
            membersListbox.Size = new Size(340, 224);
            membersListbox.TabIndex = 1;
            // 
            // chooseMemberLabel
            // 
            chooseMemberLabel.AutoSize = true;
            chooseMemberLabel.Location = new Point(273, 34);
            chooseMemberLabel.Name = "chooseMemberLabel";
            chooseMemberLabel.Size = new Size(315, 18);
            chooseMemberLabel.TabIndex = 0;
            chooseMemberLabel.Text = "Which member is checking out this book?";
            // 
            // editBookButton
            // 
            editBookButton.BackColor = SystemColors.Window;
            editBookButton.Location = new Point(572, 407);
            editBookButton.Name = "editBookButton";
            editBookButton.Size = new Size(230, 28);
            editBookButton.TabIndex = 10;
            editBookButton.Text = "Edit book";
            editBookButton.UseVisualStyleBackColor = false;
            editBookButton.Click += editBookButton_Click;
            // 
            // returnButton
            // 
            returnButton.BackColor = SystemColors.Window;
            returnButton.Location = new Point(572, 371);
            returnButton.Name = "returnButton";
            returnButton.Size = new Size(230, 28);
            returnButton.TabIndex = 9;
            returnButton.Text = "Return book";
            returnButton.UseVisualStyleBackColor = false;
            returnButton.Click += returnButton_Click;
            // 
            // checkoutButton
            // 
            checkoutButton.BackColor = SystemColors.Window;
            checkoutButton.Location = new Point(572, 335);
            checkoutButton.Name = "checkoutButton";
            checkoutButton.Size = new Size(230, 28);
            checkoutButton.TabIndex = 8;
            checkoutButton.Text = "Check out book";
            checkoutButton.UseVisualStyleBackColor = false;
            checkoutButton.Click += checkoutButton_Click;
            // 
            // newBookButton
            // 
            newBookButton.BackColor = SystemColors.Window;
            newBookButton.Location = new Point(572, 443);
            newBookButton.Name = "newBookButton";
            newBookButton.Size = new Size(230, 28);
            newBookButton.TabIndex = 7;
            newBookButton.Text = "Add new book";
            newBookButton.UseVisualStyleBackColor = false;
            newBookButton.Click += newBookButton_Click;
            // 
            // availableBooksCheckbox
            // 
            availableBooksCheckbox.AutoSize = true;
            availableBooksCheckbox.Location = new Point(203, 40);
            availableBooksCheckbox.Name = "availableBooksCheckbox";
            availableBooksCheckbox.Size = new Size(229, 22);
            availableBooksCheckbox.TabIndex = 6;
            availableBooksCheckbox.Text = "Only show available books";
            availableBooksCheckbox.UseVisualStyleBackColor = true;
            availableBooksCheckbox.CheckedChanged += availableBooksCheckbox_CheckedChanged;
            // 
            // checkedOutCheckbox
            // 
            checkedOutCheckbox.AutoSize = true;
            checkedOutCheckbox.Location = new Point(203, 6);
            checkedOutCheckbox.Name = "checkedOutCheckbox";
            checkedOutCheckbox.Size = new Size(254, 22);
            checkedOutCheckbox.TabIndex = 5;
            checkedOutCheckbox.Text = "Only show checked out books";
            checkedOutCheckbox.UseVisualStyleBackColor = true;
            checkedOutCheckbox.CheckedChanged += checkedOutCheckbox_CheckedChanged;
            // 
            // genreCombobox
            // 
            genreCombobox.FlatStyle = FlatStyle.Flat;
            genreCombobox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            genreCombobox.FormattingEnabled = true;
            genreCombobox.Items.AddRange(new object[] { "All genres" });
            genreCombobox.Location = new Point(19, 37);
            genreCombobox.Name = "genreCombobox";
            genreCombobox.Size = new Size(162, 28);
            genreCombobox.Sorted = true;
            genreCombobox.TabIndex = 4;
            genreCombobox.Text = "Filter by genre";
            genreCombobox.SelectedIndexChanged += genreCombobox_SelectedIndexChanged;
            genreCombobox.KeyPress += genreCombobox_KeyPress;
            // 
            // authorCombobox
            // 
            authorCombobox.FlatStyle = FlatStyle.Flat;
            authorCombobox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            authorCombobox.FormattingEnabled = true;
            authorCombobox.Items.AddRange(new object[] { "All authors" });
            authorCombobox.Location = new Point(19, 3);
            authorCombobox.Name = "authorCombobox";
            authorCombobox.Size = new Size(162, 28);
            authorCombobox.Sorted = true;
            authorCombobox.TabIndex = 3;
            authorCombobox.Text = "Filter by author";
            authorCombobox.SelectedIndexChanged += authorCombobox_SelectedIndexChanged;
            authorCombobox.KeyPress += authorCombobox_KeyPress;
            // 
            // languageCombobox
            // 
            languageCombobox.FlatStyle = FlatStyle.Flat;
            languageCombobox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            languageCombobox.FormattingEnabled = true;
            languageCombobox.Items.AddRange(new object[] { "All languages" });
            languageCombobox.Location = new Point(19, 71);
            languageCombobox.Name = "languageCombobox";
            languageCombobox.Size = new Size(162, 28);
            languageCombobox.Sorted = true;
            languageCombobox.TabIndex = 2;
            languageCombobox.Text = "Filter by language";
            languageCombobox.SelectedIndexChanged += languageCombobox_SelectedIndexChanged;
            languageCombobox.KeyPress += languageCombobox_KeyPress;
            // 
            // detailsLabel
            // 
            detailsLabel.AutoSize = true;
            detailsLabel.BackColor = SystemColors.Window;
            detailsLabel.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            detailsLabel.Location = new Point(572, 105);
            detailsLabel.Margin = new Padding(0, 0, 3, 0);
            detailsLabel.MaximumSize = new Size(230, 220);
            detailsLabel.MinimumSize = new Size(230, 220);
            detailsLabel.Name = "detailsLabel";
            detailsLabel.Size = new Size(230, 220);
            detailsLabel.TabIndex = 1;
            detailsLabel.Text = "Select a book to show details";
            // 
            // booksListbox
            // 
            booksListbox.BorderStyle = BorderStyle.None;
            booksListbox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            booksListbox.FormattingEnabled = true;
            booksListbox.Location = new Point(19, 105);
            booksListbox.Name = "booksListbox";
            booksListbox.Size = new Size(535, 400);
            booksListbox.Sorted = true;
            booksListbox.TabIndex = 0;
            booksListbox.SelectedIndexChanged += booksListbox_SelectedIndexChanged;
            // 
            // authorsPanel
            // 
            authorsPanel.Controls.Add(removeAuthorButton);
            authorsPanel.Controls.Add(editAuthorButton);
            authorsPanel.Controls.Add(addNewAuthorButton);
            authorsPanel.Controls.Add(authorDetailsLabel);
            authorsPanel.Controls.Add(nationalityCombobox);
            authorsPanel.Controls.Add(authorsListbox);
            authorsPanel.Location = new Point(5, 169);
            authorsPanel.Name = "authorsPanel";
            authorsPanel.Size = new Size(829, 511);
            authorsPanel.TabIndex = 9;
            authorsPanel.Visible = false;
            // 
            // removeAuthorButton
            // 
            removeAuthorButton.BackColor = SystemColors.Window;
            removeAuthorButton.Location = new Point(380, 378);
            removeAuthorButton.Name = "removeAuthorButton";
            removeAuthorButton.Size = new Size(146, 29);
            removeAuthorButton.TabIndex = 5;
            removeAuthorButton.Text = "Remove author";
            removeAuthorButton.UseVisualStyleBackColor = false;
            removeAuthorButton.Click += removeAuthorButton_Click;
            // 
            // editAuthorButton
            // 
            editAuthorButton.BackColor = SystemColors.Window;
            editAuthorButton.Location = new Point(136, 378);
            editAuthorButton.Name = "editAuthorButton";
            editAuthorButton.Size = new Size(146, 29);
            editAuthorButton.TabIndex = 4;
            editAuthorButton.Text = "Edit author";
            editAuthorButton.UseVisualStyleBackColor = false;
            editAuthorButton.Click += editAuthorButton_Click;
            // 
            // addNewAuthorButton
            // 
            addNewAuthorButton.BackColor = SystemColors.Window;
            addNewAuthorButton.Location = new Point(619, 378);
            addNewAuthorButton.Name = "addNewAuthorButton";
            addNewAuthorButton.Size = new Size(146, 29);
            addNewAuthorButton.TabIndex = 3;
            addNewAuthorButton.Text = "Add new author";
            addNewAuthorButton.UseVisualStyleBackColor = false;
            addNewAuthorButton.Click += addNewAuthorButton_Click;
            // 
            // authorDetailsLabel
            // 
            authorDetailsLabel.AutoSize = true;
            authorDetailsLabel.BackColor = SystemColors.Window;
            authorDetailsLabel.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            authorDetailsLabel.Location = new Point(435, 59);
            authorDetailsLabel.MaximumSize = new Size(330, 300);
            authorDetailsLabel.MinimumSize = new Size(330, 300);
            authorDetailsLabel.Name = "authorDetailsLabel";
            authorDetailsLabel.Size = new Size(330, 300);
            authorDetailsLabel.TabIndex = 2;
            authorDetailsLabel.Text = "Select author to display details";
            // 
            // nationalityCombobox
            // 
            nationalityCombobox.FlatStyle = FlatStyle.Flat;
            nationalityCombobox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            nationalityCombobox.FormattingEnabled = true;
            nationalityCombobox.Items.AddRange(new object[] { "All nationalities" });
            nationalityCombobox.Location = new Point(136, 25);
            nationalityCombobox.Name = "nationalityCombobox";
            nationalityCombobox.Size = new Size(166, 28);
            nationalityCombobox.Sorted = true;
            nationalityCombobox.TabIndex = 1;
            nationalityCombobox.Text = "Filter by nationality";
            nationalityCombobox.SelectedIndexChanged += nationalityCombobox_SelectedIndexChanged;
            // 
            // authorsListbox
            // 
            authorsListbox.BorderStyle = BorderStyle.None;
            authorsListbox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            authorsListbox.FormattingEnabled = true;
            authorsListbox.Location = new Point(136, 59);
            authorsListbox.Name = "authorsListbox";
            authorsListbox.Size = new Size(254, 300);
            authorsListbox.Sorted = true;
            authorsListbox.TabIndex = 0;
            authorsListbox.SelectedIndexChanged += authorsListbox_SelectedIndexChanged;
            // 
            // membersPanel
            // 
            membersPanel.Controls.Add(addNewMemberButton);
            membersPanel.Controls.Add(removeMemberButton);
            membersPanel.Controls.Add(editMemberButton);
            membersPanel.Controls.Add(returnBookButton);
            membersPanel.Controls.Add(memberBooksListbox);
            membersPanel.Controls.Add(libraryMembersLabel);
            membersPanel.Controls.Add(checkedOutBooksLabel);
            membersPanel.Controls.Add(memberDetailsLabel);
            membersPanel.Controls.Add(allMembersListbox);
            membersPanel.Location = new Point(8, 158);
            membersPanel.Name = "membersPanel";
            membersPanel.Size = new Size(842, 528);
            membersPanel.TabIndex = 10;
            membersPanel.Visible = false;
            // 
            // addNewMemberButton
            // 
            addNewMemberButton.BackColor = SystemColors.Window;
            addNewMemberButton.Location = new Point(284, 280);
            addNewMemberButton.Name = "addNewMemberButton";
            addNewMemberButton.Size = new Size(158, 29);
            addNewMemberButton.TabIndex = 8;
            addNewMemberButton.Text = "Add new member";
            addNewMemberButton.UseVisualStyleBackColor = false;
            addNewMemberButton.Click += addNewMemberButton_Click;
            // 
            // removeMemberButton
            // 
            removeMemberButton.BackColor = SystemColors.Window;
            removeMemberButton.Location = new Point(284, 229);
            removeMemberButton.Name = "removeMemberButton";
            removeMemberButton.Size = new Size(158, 29);
            removeMemberButton.TabIndex = 7;
            removeMemberButton.Text = "Remove member";
            removeMemberButton.UseVisualStyleBackColor = false;
            removeMemberButton.Click += removeMemberButton_Click;
            // 
            // editMemberButton
            // 
            editMemberButton.BackColor = SystemColors.Window;
            editMemberButton.Location = new Point(284, 180);
            editMemberButton.Name = "editMemberButton";
            editMemberButton.Size = new Size(158, 29);
            editMemberButton.TabIndex = 6;
            editMemberButton.Text = "Edit member";
            editMemberButton.UseVisualStyleBackColor = false;
            editMemberButton.Click += editMemberButton_Click;
            // 
            // returnBookButton
            // 
            returnBookButton.BackColor = SystemColors.Window;
            returnBookButton.Location = new Point(471, 180);
            returnBookButton.Name = "returnBookButton";
            returnBookButton.Size = new Size(158, 29);
            returnBookButton.TabIndex = 5;
            returnBookButton.Text = "Return book";
            returnBookButton.UseVisualStyleBackColor = false;
            returnBookButton.Visible = false;
            returnBookButton.Click += returnBookButton_Click;
            // 
            // memberBooksListbox
            // 
            memberBooksListbox.BorderStyle = BorderStyle.None;
            memberBooksListbox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            memberBooksListbox.FormattingEnabled = true;
            memberBooksListbox.Location = new Point(284, 27);
            memberBooksListbox.Name = "memberBooksListbox";
            memberBooksListbox.Size = new Size(544, 140);
            memberBooksListbox.Sorted = true;
            memberBooksListbox.TabIndex = 4;
            memberBooksListbox.Visible = false;
            // 
            // libraryMembersLabel
            // 
            libraryMembersLabel.AutoSize = true;
            libraryMembersLabel.BackColor = Color.Snow;
            libraryMembersLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            libraryMembersLabel.Location = new Point(23, 6);
            libraryMembersLabel.Name = "libraryMembersLabel";
            libraryMembersLabel.Size = new Size(190, 18);
            libraryMembersLabel.TabIndex = 3;
            libraryMembersLabel.Text = "Current library members:";
            // 
            // checkedOutBooksLabel
            // 
            checkedOutBooksLabel.AutoSize = true;
            checkedOutBooksLabel.BackColor = Color.Snow;
            checkedOutBooksLabel.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkedOutBooksLabel.Location = new Point(284, 6);
            checkedOutBooksLabel.Name = "checkedOutBooksLabel";
            checkedOutBooksLabel.Size = new Size(158, 18);
            checkedOutBooksLabel.TabIndex = 2;
            checkedOutBooksLabel.Text = "Checked out books:";
            checkedOutBooksLabel.Visible = false;
            // 
            // memberDetailsLabel
            // 
            memberDetailsLabel.AutoSize = true;
            memberDetailsLabel.BackColor = SystemColors.Window;
            memberDetailsLabel.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            memberDetailsLabel.Location = new Point(23, 180);
            memberDetailsLabel.MaximumSize = new Size(253, 280);
            memberDetailsLabel.MinimumSize = new Size(253, 280);
            memberDetailsLabel.Name = "memberDetailsLabel";
            memberDetailsLabel.Size = new Size(253, 280);
            memberDetailsLabel.TabIndex = 1;
            memberDetailsLabel.Text = "Select a member to display details";
            // 
            // allMembersListbox
            // 
            allMembersListbox.BorderStyle = BorderStyle.None;
            allMembersListbox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            allMembersListbox.FormattingEnabled = true;
            allMembersListbox.Location = new Point(23, 27);
            allMembersListbox.Name = "allMembersListbox";
            allMembersListbox.Size = new Size(253, 140);
            allMembersListbox.Sorted = true;
            allMembersListbox.TabIndex = 0;
            allMembersListbox.SelectedIndexChanged += allMembersListbox_SelectedIndexChanged;
            // 
            // removeBookButton
            // 
            removeBookButton.BackColor = SystemColors.Window;
            removeBookButton.Location = new Point(572, 477);
            removeBookButton.Name = "removeBookButton";
            removeBookButton.Size = new Size(230, 28);
            removeBookButton.TabIndex = 11;
            removeBookButton.Text = "Remove book";
            removeBookButton.UseVisualStyleBackColor = false;
            removeBookButton.Click += removeBookButton_Click;
            // 
            // MainMenu
            // 
            AutoScaleDimensions = new SizeF(9F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Snow;
            ClientSize = new Size(849, 692);
            Controls.Add(membersPanel);
            Controls.Add(searchIcon);
            Controls.Add(authorsPanel);
            Controls.Add(booksPanel);
            Controls.Add(authorsLabel);
            Controls.Add(membersLabel);
            Controls.Add(label2);
            Controls.Add(searchTextbox);
            Controls.Add(booksLabel);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MainMenu";
            Text = "Library Archive";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)searchIcon).EndInit();
            booksPanel.ResumeLayout(false);
            booksPanel.PerformLayout();
            chooseMemberPanel.ResumeLayout(false);
            chooseMemberPanel.PerformLayout();
            authorsPanel.ResumeLayout(false);
            authorsPanel.PerformLayout();
            membersPanel.ResumeLayout(false);
            membersPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox searchIcon;
        private TextBox searchTextbox;
        private Label booksLabel;
        private Label membersLabel;
        private Label label2;
        private Label authorsLabel;
        private Panel booksPanel;
        private Label detailsLabel;
        private ComboBox languageCombobox;
        private ComboBox authorCombobox;
        private ComboBox genreCombobox;
        private CheckBox checkedOutCheckbox;
        private CheckBox availableBooksCheckbox;
        private Button newBookButton;
        private Button checkoutButton;
        private Button returnButton;
        private Panel chooseMemberPanel;
        private Button confirmMemberButton;
        private ListBox membersListbox;
        private Label chooseMemberLabel;
        private Button editBookButton;
        private Button backToBooksButton;
        private Panel authorsPanel;
        private Label authorDetailsLabel;
        private Button editAuthorButton;
        private Button addNewAuthorButton;
        private Button removeAuthorButton;
        public ComboBox nationalityCombobox;
        public ListBox authorsListbox;
        public ListBox booksListbox;
        private Panel membersPanel;
        private Label checkedOutBooksLabel;
        private ListBox memberBooksListbox;
        private Label libraryMembersLabel;
        private Button returnBookButton;
        private Button editMemberButton;
        private Button addNewMemberButton;
        private Button removeMemberButton;
        public ListBox allMembersListbox;
        public Label memberDetailsLabel;
        private Button removeBookButton;
    }
}
