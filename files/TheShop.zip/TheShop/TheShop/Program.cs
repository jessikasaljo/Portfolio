﻿namespace TheShop;
internal class Program
{
    static void Main(string[] args)
    {

        ShopProgram shopProgram = new ShopProgram();
        shopProgram.ItemsToItemList();
        shopProgram.Run();

    }
}

