# TheShop

Första inlämningsuppgiften på programmet för Objektorienterad systemutveckling på NBI/Handelsakademin.

Kommentar till programmet:
Jag skrev detta program på Mac och inställningen på den datorn när programmet har kört färdigt är att det stängdes ner så fort det hade kört klart, vilket innebarr att användaren inte hade tid att läsa de sista meddelandena som står. Jag lade därför till en Console.ReadLine() i slutet av programmet så att man hinner läsa färdigt innan man avslutar helt.
